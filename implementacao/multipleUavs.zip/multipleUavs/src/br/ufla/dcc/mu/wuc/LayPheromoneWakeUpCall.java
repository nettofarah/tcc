package br.ufla.dcc.mu.wuc;

import br.ufla.dcc.grubix.simulator.Address;
import br.ufla.dcc.grubix.simulator.event.WakeUpCall;

public class LayPheromoneWakeUpCall extends WakeUpCall {

	public LayPheromoneWakeUpCall(Address sender, double delay) {
		super(sender, delay);
		// TODO Auto-generated constructor stub
	}

}
