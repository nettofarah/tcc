package br.ufla.dcc.mu.wuc;

import br.ufla.dcc.grubix.simulator.Address;
import br.ufla.dcc.grubix.simulator.event.WakeUpCall;

public class MeasureWakeUpCall extends WakeUpCall {

	public MeasureWakeUpCall(Address sender,double delay) {
		super(sender, delay);
		// TODO Auto-generated constructor stub
	}

}
